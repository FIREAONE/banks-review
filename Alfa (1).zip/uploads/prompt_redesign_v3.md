# Промпт для Claude Artifacts — редизайн v3
# Вставь в новый чат на claude.ai, прикрепи файл Топ-5_банков___Flow_Art_v2.html

---

Перед тобой HTML-презентация «Топ-5 банков, состоятельный сегмент 2026». Нужен комплексный редизайн. Все данные (ставки, суммы, тексты) оставь без изменений. Покажи результат как Artifact.

---

## ГЛАВНАЯ ПРОБЛЕМА: название банка не видно

Сейчас название банка (ВТБ, Сбербанк и т.д.) спрятано в мелком `.eyebrow`. Это нужно полностью переосмыслить.

**Новая визуальная иерархия каждого слайда (сверху вниз):**

1. **Логотип банка** — inline SVG, крупный, верхний левый угол, высота ~56px
2. **Название банка** — отдельный огромный текст, `font-size: clamp(5rem, 14vw, 13rem)`, font-weight 800, letter-spacing -0.03em — это главный визуальный якорь слайда, сразу под логотипом или рядом
3. Слоган / eyebrow — мелко, под названием
4. Продуктовые данные — как сейчас

Убери текущий `.display` со слоганами («Капитал Под Защитой» и т.п.) — он мешает и занимает место названия банка. Вместо него — просто огромное название банка.

---

## ЛОГОТИПЫ — inline SVG для каждого банка

Все логотипы реализуй как inline SVG внутри HTML. Никаких внешних картинок. Вот точные фирменные логотипы:

### ВТБ
```
Логотип: белые буквы «ВТБ» с синей прямоугольной плашкой под ними (фирменный знак).
SVG-реализация:
<svg height="56" viewBox="0 0 160 56" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Буквы ВТБ белым -->
  <text x="0" y="44" font-family="'Plus Jakarta Sans', sans-serif" font-size="52" font-weight="800" fill="white" letter-spacing="-2">ВТБ</text>
  <!-- Синяя полоса-подчёркивание фирменная -->
  <rect x="0" y="50" width="140" height="5" rx="2" fill="#4f8ef7"/>
</svg>
Разместить: верхний левый, padding совпадает с container
```

### Сбербанк
```
Логотип: зелёный круг с белой галочкой внутри + текст «Сбер» рядом.
SVG-реализация:
<svg height="56" viewBox="0 0 220 56" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Зелёный круг -->
  <circle cx="28" cy="28" r="28" fill="#fff" opacity="0.9"/>
  <!-- Галочка -->
  <path d="M14 28 L24 38 L44 18" stroke="#21A038" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  <!-- Текст Сбер -->
  <text x="68" y="38" font-family="'Plus Jakarta Sans', sans-serif" font-size="36" font-weight="800" fill="white" letter-spacing="-1">Сбер</text>
</svg>
```

### Альфа-Банк
```
Логотип: белая буква «А» в красном круге + текст «Альфа-Банк».
SVG-реализация:
<svg height="56" viewBox="0 0 280 56" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Круг -->
  <circle cx="28" cy="28" r="28" fill="white"/>
  <!-- Буква А красная -->
  <text x="28" y="38" text-anchor="middle" font-family="'Plus Jakarta Sans', sans-serif" font-size="36" font-weight="900" fill="#EF3124">А</text>
  <!-- Текст -->
  <text x="68" y="38" font-family="'Plus Jakarta Sans', sans-serif" font-size="28" font-weight="700" fill="white" letter-spacing="-0.5">Альфа-Банк</text>
</svg>
```

### Газпромбанк
```
Логотип: синий прямоугольник с белыми буквами «ГПБ» + полное название.
SVG-реализация:
<svg height="56" viewBox="0 0 320 56" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Плашка ГПБ -->
  <rect x="0" y="8" width="72" height="40" rx="4" fill="#1a3a6b"/>
  <rect x="0" y="8" width="72" height="40" rx="4" fill="none" stroke="#7fb3ff" stroke-width="1.5"/>
  <text x="36" y="33" text-anchor="middle" font-family="'Plus Jakarta Sans', sans-serif" font-size="18" font-weight="800" fill="white">ГПБ</text>
  <!-- Название -->
  <text x="84" y="36" font-family="'Plus Jakarta Sans', sans-serif" font-size="24" font-weight="700" fill="white" letter-spacing="-0.5">Газпромбанк</text>
</svg>
```

### Т-Банк
```
Логотип: жёлтый круг с чёрной буквой «Т» + текст «Т-Банк».
SVG-реализация:
<svg height="56" viewBox="0 0 180 56" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Жёлтый круг -->
  <circle cx="28" cy="28" r="28" fill="#FFDD2D"/>
  <!-- Буква Т чёрная -->
  <text x="28" y="38" text-anchor="middle" font-family="'Plus Jakarta Sans', sans-serif" font-size="34" font-weight="900" fill="#0d0f14">T</text>
  <!-- Текст Т-Банк тёмный т.к. слайд жёлтый -->
  <text x="68" y="38" font-family="'Plus Jakarta Sans', sans-serif" font-size="32" font-weight="800" fill="#0d0f14" letter-spacing="-1">Т-Банк</text>
</svg>
```

---

## ОГРОМНОЕ НАЗВАНИЕ БАНКА — новый главный элемент

Сразу под логотипом (или рядом) добавь отдельный блок:

```html
<div class="bank-title">ВТБ</div>  <!-- для каждого банка своё -->
```

CSS:
```css
.bank-title {
  font-size: clamp(6rem, 16vw, 15rem);
  font-weight: 800;
  line-height: 0.9;
  letter-spacing: -0.04em;
  text-transform: uppercase;
  /* цвет: для тёмных фонов — white с opacity 1, для жёлтого (Т-Банк) — #0d0f14 */
}
```

Названия:
- ВТБ → «ВТБ»
- Сбербанк → «Сбер»
- Альфа → «Альфа»
- Газпромбанк → «Газпром»
- Т-Банк → «Т-Банк»

---

## ФИРМЕННЫЕ ДЕКОРАТИВНЫЕ ЭЛЕМЕНТЫ (усиленные)

Все декоры должны быть заметны — opacity не ниже 0.12 для основных форм. Вот обновлённые требования:

### ВТБ (#0a2a6c)
- Три концентрических окружности в правом нижнем углу: stroke #4f8ef7, opacity 0.20 / 0.14 / 0.09, r = 280/420/560
- Тонкая синяя сетка из 4 вертикальных линий справа (x от 1400 до 1900), stroke #4f8ef7, opacity 0.08
- Надпись «ВТБ» как SVG-фон: font-size 500, fill white, opacity 0.03, x=1920 text-anchor=end, y=1080 — огромный водяной знак

### Сбербанк (#21A038)
- Большой круг (r=500) за правым краем, fill #1e9636, opacity 0.35 — объём
- Второй круг поменьше (r=280), fill none, stroke white, opacity 0.10
- 8 маленьких кружков (#b8f0c8, opacity 0.45–0.6, r=5–18) разбросаны в правой половине
- Фирменная галочка Сбера: SVG path, stroke white, stroke-width 18, opacity 0.07, размером 600px в правом нижнем углу

### Альфа (#EF3124)
- Огромная буква «А» (SVG text, font-size 700, fill white, opacity 0.05, text-anchor=end, x=1980, y=1100) — водяной знак
- 5 тонких диагональных линий (угол 35°), stroke white, opacity 0.10, stroke-width 1.5 — равномерно по правой половине
- Один крупный белый треугольник (SVG polygon, fill white, opacity 0.04) в правом нижнем углу

### Газпромбанк (#0F1B2E)
- 3 правильных шестиугольника: stroke #7fb3ff, fill none, opacity 0.10/0.07/0.05, стороны 120/200/300px — правая часть, разные позиции
- Плавная волна (SVG path, несколько cubic bezier кривых), stroke #e8c96e, fill none, stroke-width 2.5, opacity 0.18 — идёт от середины правого края вниз
- Тонкая горизонтальная золотая линия (#e8c96e, opacity 0.35, stroke-width 1) под блоком bank-title

### Т-Банк (#FFDD2D)
- Огромная буква «Т»: SVG text, font-size 700, fill #0d0f14, opacity 0.06, text-anchor=end, x=1980, y=1100
- 3 круга разного размера: stroke #0d0f14, fill none, opacity 0.08/0.06/0.04, r=180/300/450 — правый нижний угол
- Две оранжевые полосы (#ff6f00): rect, высота 8px, ширина 35vw, opacity 0.15 — горизонтальные, в нижней части справа

---

## LAYOUT — новая структура слайда банка

Замени текущий layout на следующий порядок блоков внутри `.flow-art-container`:

```
1. [SVG логотип] + [eyebrow справа] — одна строка flex, justify: space-between
2. [.bank-title] — огромное название, главный визуальный элемент
3. <hr>
4. [.lead] — короткий описательный текст (оставить как есть)
5. <hr>
6. [.products] — 4 карточки в сетке 2×2
7. <hr>
8. [.row .col] — нижняя строка с условиями
```

---

## ПРОДУКТОВЫЕ КАРТОЧКИ — доработка

```css
.product {
  border-left: 4px solid; /* цвет — акцентный для каждого банка */
  border-radius: 12px;
  padding: 1.4rem 1.6rem;
  background: rgba(255,255,255, 0.08);
  backdrop-filter: blur(4px);
}
```

Цвета border-left по банкам:
- ВТБ: #4f8ef7
- Сбер: rgba(255,255,255,0.6)
- Альфа: rgba(255,255,255,0.6)
- Газпром: #e8c96e
- Т-Банк: #ff6f00

`.prate .v` (ставка): добавь `text-shadow: 0 2px 20px currentColor` — свечение

---

## COVER-СЛАЙД — улучшение

Добавь на cover-слайд строчку с логотипами всех 5 банков снизу — горизонтальный ряд маленьких тегов:

```html
<div class="bank-pills">
  <span class="pill vtb">ВТБ</span>
  <span class="pill sber">Сбер</span>
  <span class="pill alfa">Альфа</span>
  <span class="pill gpb">ГПБ</span>
  <span class="pill tbank">Т-Банк</span>
</div>
```

```css
.bank-pills { display: flex; gap: 12px; flex-wrap: wrap; }
.pill {
  font-size: 12px; font-weight: 700; letter-spacing: 0.1em;
  padding: 6px 16px; border-radius: 20px; text-transform: uppercase;
}
.pill.vtb    { background: #0a2a6c; color: #7fb3ff; border: 1px solid #4f8ef7; }
.pill.sber   { background: #21A038; color: #fff; }
.pill.alfa   { background: #EF3124; color: #fff; }
.pill.gpb    { background: #0F1B2E; color: #7fb3ff; border: 1px solid #7fb3ff; }
.pill.tbank  { background: #FFDD2D; color: #0d0f14; }
```

---

## ШРИФТЫ — финальная проверка

Убедись что все эти размеры применены:
- `.eyebrow`: `clamp(0.72rem, 1vw, 0.88rem)` — мелко, декоративно
- `.lead`: `clamp(1.05rem, 2vw, 1.6rem)` — читаемо
- `.pname`: `clamp(1rem, 1.6vw, 1.25rem)` — имя продукта
- `.prate .v`: `clamp(2.2rem, 4.5vw, 4rem)` — ставка большая
- `.pnote`: `clamp(0.88rem, 1.3vw, 1.05rem)`, opacity 0.88 — читаемо
- `.col p`: `clamp(0.9rem, 1.3vw, 1.05rem)` — читаемо
- `.col h4`: `clamp(0.7rem, 1vw, 0.82rem)` — лейбл

---

## НЕ ТРОГАТЬ:
- Все данные: ставки, суммы, порядок банков, тексты продуктов
- JavaScript: прогресс-точки, ScrollTrigger-анимации
- FlowSection-архитектуру и scroll mechanics
- Итоговый слайд 06 (Сравнение) — оставить как есть
- Шрифт Plus Jakarta Sans

---

Покажи как Artifact.
